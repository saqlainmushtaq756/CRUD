import {
  Box,
  IconButton,
  InputAdornment,
  ListItem,
  TextField,
  Typography,
} from "@mui/material";
import React, { useState } from "react";
import todo from "../assets/images/todo.png";
import BackHandIcon from "@mui/icons-material/BackHand";
import AddIcon from "@mui/icons-material/Add";
import CheckIcon from "@mui/icons-material/Check";
import DeleteForeverIcon from "@mui/icons-material/DeleteForever";

function Todo() {
  const [inputValues, setInputValues] = useState("");
  const [submitValues, setSubmitValues] = useState([]);
  const [deletButton, setDeletButton] = useState(false);
  const [checkButton, setCheckButton] = useState(false);

  const handleInput = (e) => {
    setInputValues(e.target.value);
  };
  const handleSubmit = () => {
    if (!inputValues) return;

    if (!submitValues.includes(inputValues)) {
      setSubmitValues((prev) => {
        return [...prev, inputValues];
      });
      setInputValues("");
    }
    setInputValues("");
  };
  // const handleDeletButton = () => {
  //   setDeletButton("Delet button is clicked :", true);
  //   console.log("button is clicked know", true);
  // };
  const handleDeletButton = (index) => {
    setSubmitValues((prev) => prev.filter((_, i) => i !== index));
  };
  const handleCheckButton = (index) => {
    console.log("here is index value", index);
    setCheckButton("check button is clicked:", true);
    console.log("button is clicked know", true);
  };
  return (
    <>
      {/* this is a todo list jani */}
      <Box
        sx={{
          backgroundColor: "#3f51b5",
          color: "white",
          height: "100vh",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <Box
          border={"1px solid white"}
          p={2}
          textAlign={"center"}
          bgcolor={"white"}
          color={"black"}
          width={450}
          height={400}
          overflow={"auto"}
          borderRadius={"5%"}
          boxShadow={"2px 2px 0.5px white"}
        >
          <Box>
            <img src={todo} alt="image is here" height={"50px"} />
            <Typography>Add your list here ✌</Typography>
            <TextField
              slotProps={{
                input: {
                  startAdornment: (
                    <InputAdornment position="start"> ✍</InputAdornment>
                  ),
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton onClick={() => handleSubmit()}>
                        <AddIcon />
                      </IconButton>
                    </InputAdornment>
                  ),
                },
              }}
              size="small"
              fullWidth
              sx={{
                backgroundColor: "white",
                color: "black",
                fontSize: "8px",
                width: "70%",
              }}
              value={inputValues}
              onChange={(e) => {
                handleInput(e);
              }}
            />
          </Box>
          <ul>
            {submitValues.map((value, index) => (
              <ListItem
                key={index}
                sx={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  padding: "4px 5px",
                  borderBottom: "1px solid #ccc",
                  width: 380,
                }}
              >
                <Typography variant="subtitle1">{value}</Typography>
                <Box>
                  <IconButton
                    color="primary"
                    onClick={() => handleCheckButton(index)}
                    value={checkButton}
                  >
                    <CheckIcon />
                  </IconButton>
                  <IconButton
                    color="secondary"
                    onClick={() => handleDeletButton(index)}
                    value={deletButton}
                  >
                    <DeleteForeverIcon />
                  </IconButton>
                </Box>
              </ListItem>
            ))}
          </ul>
        </Box>
      </Box>
    </>
  );
}

export default Todo;
