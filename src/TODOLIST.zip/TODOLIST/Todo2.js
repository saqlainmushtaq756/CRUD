import {
  Box,
  Button,
  IconButton,
  InputAdornment,
  ListItem,
  TextField,
  Typography,
} from "@mui/material";
import React, { useState } from "react";
import todo from "../assets/images/todo.png";
import BackHandIcon from "@mui/icons-material/BackHand";
import AddIcon from "@mui/icons-material/Add";
import CheckIcon from "@mui/icons-material/Check";
import DeleteForeverIcon from "@mui/icons-material/DeleteForever";
import EditIcon from "@mui/icons-material/Edit";
import CloseIcon from "@mui/icons-material/Close";

function Todo2() {
  const [inputData, setInputData] = useState("");
  const [items, setItems] = useState([]);
  console.log(items);
  const handlesubmit = () => {
    if (!inputData) {
      return "";
    } else {
      const newInputData = {
        id: new Date().getTime().toString(),
        name: inputData,
      };
      setItems([...items, newInputData]);
    }
    setInputData("");
  };
  const handlDelete = (index) => {
    const updatedItems = items.filter((curentItem) => {
      return curentItem.id !== index;
    });
    setItems(updatedItems);
  };
  return (
    <>
      {/* this is a todo list jani */}
      <Box
        sx={{
          backgroundColor: "#3f51b5",
          color: "white",
          height: "100vh",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <Box
          border={"1px solid white"}
          p={2}
          textAlign={"center"}
          bgcolor={"white"}
          color={"black"}
          width={450}
          height={400}
          overflow={"auto"}
          borderRadius={"5%"}
          boxShadow={"2px 2px 0.5px white"}
        >
          <Box>
            <img src={todo} alt="image is here" height={"50px"} />
            <Typography>Add your list here ✌</Typography>
            <TextField
              slotProps={{
                input: {
                  startAdornment: (
                    <InputAdornment position="start"> ✍</InputAdornment>
                  ),
                  endAdornment: (
                    <InputAdornment position="end">
                      <IconButton onClick={handlesubmit}>
                        <AddIcon />
                      </IconButton>
                    </InputAdornment>
                  ),
                },
              }}
              size="small"
              fullWidth
              sx={{
                backgroundColor: "white",
                color: "black",
                fontSize: "8px",
                width: "70%",
              }}
              onChange={(e) => setInputData(e.target.value)}
              value={inputData}
            />
          </Box>

          <ul>
            {items.map((curretValue, index) => {
              return (
                <ListItem
                  key={index}
                  sx={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    padding: "4px 5px",
                    borderBottom: "1px solid #ccc",
                    width: 380,
                  }}
                >
                  <Typography variant="subtitle1">
                    {curretValue.name}
                  </Typography>
                  <Box>
                    <IconButton color="primary">
                      <EditIcon />
                    </IconButton>
                    <IconButton
                      color="secondary"
                      onClick={() => {
                        return handlDelete(curretValue.id);
                      }}
                    >
                      <DeleteForeverIcon />
                    </IconButton>
                  </Box>
                </ListItem>
              );
            })}
          </ul>
          <Button variant="contained" mt={5} onClick={() => setItems([])}>
            <CloseIcon /> <span>remove all</span>
          </Button>
        </Box>
      </Box>
    </>
  );
}

export default Todo2;
